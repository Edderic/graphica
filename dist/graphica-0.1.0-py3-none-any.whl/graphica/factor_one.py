"""
FactorOne
"""

class FactorOne:
    """
    Class that makes summing easier.
    """

    def prod(self, other):
        """
        Parameters:
            other: Factor
        """

        return other

    def get_variables(self):
        """
        Returns: list
            Empty.
        """
        return []
